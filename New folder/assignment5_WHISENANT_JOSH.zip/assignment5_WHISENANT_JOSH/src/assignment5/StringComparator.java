package assignment5;

import java.util.Comparator;

public class StringComparator implements Comparator<String>{

	// negative if the first input is less than the second
	public int compare(String o1, String o2) {
		return o1.compareTo(o2);
		
		
	}
	
	

}